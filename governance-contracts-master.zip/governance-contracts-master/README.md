# 1inch Governance Contracts

[![Build Status](https://github.com/1inch-exchange/governance-contracts/workflows/CI/badge.svg)](https://github.com/1inch-exchange/governance-contracts/actions)
[![Coverage Status](https://coveralls.io/repos/github/1inch-exchange/governance-contracts/badge.svg?branch=master)](https://coveralls.io/github/1inch-exchange/governance-contracts?branch=master)



## Mainnet Contract Addresses

[Governance Mothership](https://etherscan.io/address/0xA0446D8804611944F1B527eCD37d7dcbE442caba)

[Exchange Governance](https://etherscan.io/address/0xB33839E05CE9Fc53236Ae325324A27612F4d110D)

[Governance Rewards](https://etherscan.io/address/0x0F85A912448279111694F4Ba4F85dC641c54b594)
